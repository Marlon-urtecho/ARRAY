package Bidimencional;

import java.util.Scanner;

public class Operaciones {

public static void main(String[] args) {
	// TODO Auto-generated method stub
	Scanner tec = new Scanner(System.in);    
	
//deaclarando variables	
	int n;
	int sum = 0;		    
	int dotProduct = 0;
 
System.out.print("Ingrese la dimencion del arreglo:");
n = tec.nextInt();

 	int a[] = new int[n];
 	int b[] = new int[n];
 
 System.out.println("Ingresa los valores del 1er vector:");
 		for(int i = 0; i < n ; i++) {
 			a[i] = tec.nextInt();
 		}

 System.out.println("Ingresa los valores del 2do vector:");
	
	for(int i = 0; i < n ; i++) {
 			b[i] = tec.nextInt();
 		}
	
 		for(int i = 0; i < n ; i++) {
 			dotProduct += a[i] * b[i];
 		}
 		
 		System.out.println("Producto de los vectores: "+dotProduct);
 		
 		
 		for(int i = 0; i < n ; i++) {
 			sum += a[i] * b[i];
 		}
 		
 		if(sum == 0) {
 			
 			System.out.println("Los arreglos son ortogonales.");
 		
 		} else {
 			
 			System.out.println("Los arreglos no son ortogonales.");
 		
 		}
 		
 		float product = 1;
 		float moduleA = 1;
 		float moduleB = 1;
 		
  for(int i = 0; i < n ; i++) {
	 
 		product *= a[i] * b[i];
 		moduleA *= Math.abs(a[i]);
 		moduleB *= Math.abs(b[i]);
 }
 
 float z = product / (moduleA * moduleB);
 System.out.println("Z: "+z);
			
			
	}

}
