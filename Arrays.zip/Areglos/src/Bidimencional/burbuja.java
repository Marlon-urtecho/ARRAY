package Bidimencional;

import java.util.Scanner;

public class burbuja {

	public static void main(String[] args) {
	//Este programa ordena los numeros de un vector
	Scanner tc =new Scanner(System.in);
	int[] vec;
    int aux, n, valor = 0;

    System.out.println("Ingrese la cantidad de elementos del vector");
    n = tc.nextInt();
    vec = new int[n];

    for (int i = 0; i < n; i++) {
        System.out.printf("Ingrese el valor para el elemento %d: ", i);
        vec[i] = tc.nextInt();
    }

    System.out.println("Arreglo desordenado:");
    imprimirArreglo(vec);

    // Ordenando el arreglo
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - 1 - i; j++) {
            if (vec[j] > vec[j + 1]) {
                aux = vec[j];
                vec[j] = vec[j + 1];
                vec[j + 1] = aux;
            }
        }
    }

    System.out.println("\nArreglo ordenado:");
    imprimirArreglo(vec);

    tc.close();
}

  public static void imprimirArreglo(int[] arr) {
    
	  System.out.println("Index \t Valor");
    for (int i = 0; i < arr.length; i++) {
        System.out.printf("%d\t%d\n", i, arr[i]);
    }
	
  }
}
