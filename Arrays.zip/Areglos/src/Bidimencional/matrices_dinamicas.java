package Bidimencional;

import java.util.Scanner;

public class matrices_dinamicas {

	public static void main(String[] args) {
	
	//Este programa trabaja con matrices dinamicas
	Scanner tec = new Scanner(System.in);
	//Declarando varibles
		int f = 3, c = 3;
		int contador = 1;
		
		
	//Declarando arreglo
	 int myNumbers[][] = new int [f][c];
		
	myNumbers = new int[f][c];
	
	for (int i = 0; i < myNumbers.length; ++i) {
	      for(int j = 0; j < myNumbers.length; ++j) {
	        System.out.println(myNumbers[f][c]);
		
	       myNumbers[f][c]= contador;
		
		contador++; 
			
		System.out.println("["+myNumbers[f][c]+"]");	
		}
		System.out.println(" ");	
	   }
		
	}
	
}
