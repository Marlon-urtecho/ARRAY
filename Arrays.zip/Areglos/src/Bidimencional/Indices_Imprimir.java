package Bidimencional;

public class Indices_Imprimir {

	public static void main(String[] args) {
	
	//Este programa sirve para una matriz 2x2

	//crenado nustro arreglo
	int numeros [][]= new int [2][2];
		
	numeros [0][0]= 5;
	numeros [0][1]= 2;	
	numeros [1][0]= 2;	
	numeros [1][1]= 5;	
		
	//imprimiendo los indices del arreglo
	System.out.print("[" + numeros[0][0] + "]");
	System.out.println("[" + numeros[0][1] + "]");
	System.out.print("[" + numeros[1][0] + "]");
	System.out.print("[" + numeros[1][1] + "]");
	
	}

}